import cv2  # Importing the OpenCV library for computer vision tasks
import mediapipe as md  # Importing the Mediapipe library for pose estimation

md_drawing = md.solutions.drawing_utils  # Importing drawing utilities from Mediapipe
md_drawing_styles = md.solutions.drawing_styles  # Importing drawing styles from Mediapipe
md_pose = md.solutions.pose  # Importing the pose estimation module from Mediapipe

count = 0  # Initializing a variable to keep track of the number of push-ups
position = None  # Initializing a variable to store the current arm position

cap = cv2.VideoCapture(0)  # Creating a VideoCapture object to access the camera (index 0)

with md_pose.Pose(
    min_detection_confidence=0.7,  # Minimum confidence threshold for successful pose detection
    min_tracking_confidence=0.7  # Minimum confidence threshold for successful pose tracking
) as pose:  # Using the pose estimation module as a context manager
    while cap.isOpened():  # Looping until the camera is open and capturing frames
        success, image = cap.read()  # Reading the next frame from the camera
        if not success:  # Checking if the frame read was empty
            print('Empty camera')  # Printing a message indicating an empty camera
            break  # Breaking out of the loop if the camera is empty

        image = cv2.cvtColor(cv2.flip(image, 1), cv2.COLOR_BGR2RGB)  # Flipping and converting the image to RGB color space
        result = pose.process(image)  # Processing the image to estimate the pose

        imlist = []  # Creating an empty list to store the pose landmarks

        if result.pose_landmarks:  # Checking if pose landmarks were detected in the image
            md_drawing.draw_landmarks(
                image, result.pose_landmarks, md_pose.POSE_CONNECTIONS
            )  # Drawing the pose landmarks on the image using the drawing utilities

            for id, im in enumerate(result.pose_landmarks.landmark):
                # Looping over each pose landmark and storing its index and pixel coordinates
                h, w, _ = image.shape  # Getting the height and width of the image
                X, Y = int(im.x * w), int(im.y * h)  # Scaling the landmark coordinates by image dimensions
                imlist.append([id, X, Y])  # Appending the landmark index and coordinates to the list

        if len(imlist) != 0:  # Checking if any pose landmarks were detected
            if ((imlist[12][2] - imlist[14][2]) >= 15 and (imlist[11][2] - imlist[13][2]) >= 15):
                # Checking if the arm is in a downward position based on the vertical difference of specific landmarks
                position = "down"  # Setting the arm position as "down" if the conditions are met
            elif ((imlist[12][2] - imlist[14][2]) <= 5 and (imlist[11][2] - imlist[13][2]) <= 5) and position == "down":
                # Checking if the arm is in an upward position based on the vertical difference of specific landmarks
                position = "up"  # Setting the arm position as "up" if the conditions are met
                count += 1  # Incrementing the push-up count by 1
                print(count)  # Printing the current push-up count
                print('PUSH UP')  # Printing a message indicating a push-up
            else:
                position = "other"  # Setting the arm position as "other" if none of the conditions are met
                print('NOT A PUSH UP')  # Printing a message indicating it's not a push-up

        cv2.imshow("Push-up counter", cv2.flip(image, 1))  # Displaying the image with pose landmarks
        key = cv2.waitKey(1)  # Waiting for a key press with a delay of 1 millisecond
        if key == ord("q"):  # Checking if the "q" key was pressed
            break  # Breaking out of the loop if the "q" key was pressed

cap.release()  # Releasing the camera resources
